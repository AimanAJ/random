﻿using System.Text.Json.Serialization;

namespace chatAi.Models
{
	// 1. نماذج المحادثة الخاصة بتطبيقنا
	public class ChatMessage
	{
		public string? Author { get; set; }
		public string? Text { get; set; }
	}

	public class ChatViewModel
	{
		public List<ChatMessage> History { get; set; } = new List<ChatMessage>();
		public string? CurrentMessage { get; set; }
	}

	// 2. نماذج لوصف شكل الرد القادم من Google API
	public class GeminiApiResponse
	{
		[JsonPropertyName("candidates")]
		public List<Candidate>? Candidates { get; set; }
	}

	public class Candidate
	{
		[JsonPropertyName("content")]
		public Content? Content { get; set; }
	}

	public class Content
	{
		[JsonPropertyName("parts")]
		public List<Part>? Parts { get; set; }
	}

	public class Part
	{
		[JsonPropertyName("text")]
		public string? Text { get; set; }
	}

	// 3. نموذج الخطأ الافتراضي للمشروع

}