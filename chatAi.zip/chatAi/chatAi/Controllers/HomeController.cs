﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using chatAi.Models;

namespace chatAi.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;
		private readonly IHttpClientFactory _httpClientFactory;
		private readonly string? _geminiApiKey;

		// عند بدء تشغيل التطبيق، يتم قراءة الإعدادات والمفتاح من ملف appsettings.json
		public HomeController(ILogger<HomeController> logger, IHttpClientFactory httpClientFactory, IConfiguration configuration)
		{
			_logger = logger;
			_httpClientFactory = httpClientFactory;
			_geminiApiKey = configuration["Gemini:ApiKey"]; // <-- هنا تتم قراءة المفتاح
		}

		// هذا الـ Action يعرض الصفحة عندما تزورها لأول مرة
		[HttpGet]
		public IActionResult Index()
		{
			var viewModel = new ChatViewModel();
			viewModel.History.Add(new ChatMessage { Author = "AI", Text = "أهلاً بك، كيف يمكنني مساعدتك؟" });
			return View(viewModel);
		}

		// هذا الـ Action يستقبل البيانات عندما تضغط على زر "إرسال"
		[HttpPost]
		public async Task<IActionResult> Index(ChatViewModel viewModel)
		{
			if (!string.IsNullOrEmpty(viewModel.CurrentMessage))
			{
				// أضف رسالة المستخدم إلى السجل
				viewModel.History.Add(new ChatMessage { Author = "User", Text = viewModel.CurrentMessage });

				// اطلب رداً من الذكاء الاصطناعي
				string aiResponse = await GetAiResponseFromServer(viewModel.CurrentMessage);
				viewModel.History.Add(new ChatMessage { Author = "AI", Text = aiResponse });
			}

			// أفرغ حقل الإدخال استعداداً للرسالة التالية
			viewModel.CurrentMessage = string.Empty;

			// أعد عرض الصفحة مع كامل سجل المحادثة المحدث
			return View(viewModel);
		}

		// تابع مساعد للاتصال بـ Google Gemini API
		private async Task<string> GetAiResponseFromServer(string prompt)
		{
			if (string.IsNullOrEmpty(_geminiApiKey))
			{
				return "خطأ: مفتاح الـ API غير موجود في ملف الإعدادات.";
			}

			var client = _httpClientFactory.CreateClient();
			var apiUrl = $"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key={_geminiApiKey}";

			var requestBody = new { contents = new[] { new { parts = new[] { new { text = prompt } } } } };

			var jsonContent = JsonSerializer.Serialize(requestBody);
			var httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

			var response = await client.PostAsync(apiUrl, httpContent);

			if (!response.IsSuccessStatusCode)
			{
				_logger.LogError("API Error: {error}", await response.Content.ReadAsStringAsync());
				return "حدث خطأ أثناء الاتصال بخدمة الذكاء الاصطناعي.";
			}

			var responseContent = await response.Content.ReadAsStringAsync();

			try
			{
				var apiResponse = JsonSerializer.Deserialize<GeminiApiResponse>(responseContent);
				string? aiReply = apiResponse?.Candidates?.FirstOrDefault()?.Content?.Parts?.FirstOrDefault()?.Text;
				return aiReply ?? "لم يتم استلام رد.";
			}
			catch (JsonException ex)
			{
				_logger.LogError(ex, "Failed to deserialize JSON response.");
				return "حدث خطأ في تحليل رد الذكاء الاصطناعي.";
			}
		}

		public IActionResult Privacy()
		{
			return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}