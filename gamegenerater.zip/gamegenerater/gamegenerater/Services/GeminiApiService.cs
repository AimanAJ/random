﻿using System.Text;
using System.Text.Json;
using gamegenerater.Models;

namespace gamegenerater.Services
{
    public class GeminiApiService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly ILogger<GeminiApiService> _logger;
        private readonly string _apiKey;
        
        // النماذج المتاحة
        private readonly string[] _availableModels = 
        {
            "gemini-1.5-flash",
            "gemini-1.5-pro",
            "gemini-pro"
        };

        public GeminiApiService(HttpClient httpClient, IConfiguration configuration, ILogger<GeminiApiService> logger)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _logger = logger;
            _apiKey = _configuration["GeminiApi:ApiKey"] ?? "YOUR_API_KEY_HERE";
        }

        public async Task<string> GenerateGameAsync(string gameDescription)
        {
            try
            {
                _logger.LogInformation("Starting game generation");
                
                // جرب النماذج المختلفة
                foreach (var model in _availableModels)
                {
                    try
                    {
                        _logger.LogInformation($"Trying model: {model}");
                        var result = await TryGenerateWithModel(gameDescription, model);
                        if (!string.IsNullOrEmpty(result))
                        {
                            _logger.LogInformation($"Successfully generated game with model: {model}");
                            return result;
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning($"Model {model} failed: {ex.Message}");
                        continue;
                    }
                }

                // إذا فشلت كل النماذج، ارجع لعبة بسيطة
                _logger.LogWarning("All models failed, returning fallback game");
                return GetFallbackGame(gameDescription);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GenerateGameAsync");
                throw new Exception($"خطأ في إنشاء اللعبة: {ex.Message}");
            }
        }

        private async Task<string> CallGeminiApi(string prompt, string model)
        {
            var baseUrl = $"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent";
            
            var requestBody = new
            {
                contents = new[]
                {
                    new
                    {
                        parts = new[]
                        {
                            new { text = prompt }
                        }
                    }
                },
                generationConfig = new
                {
                    temperature = 0.7,
                    topK = 1,
                    topP = 1,
                    maxOutputTokens = 8192
                },
                safetySettings = new[]
                {
                    new {
                        category = "HARM_CATEGORY_HARASSMENT",
                        threshold = "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    new {
                        category = "HARM_CATEGORY_HATE_SPEECH",
                        threshold = "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    new {
                        category = "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                        threshold = "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    new {
                        category = "HARM_CATEGORY_DANGEROUS_CONTENT",
                        threshold = "BLOCK_MEDIUM_AND_ABOVE"
                    }
                }
            };

            var json = JsonSerializer.Serialize(requestBody, new JsonSerializerOptions 
            { 
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase 
            });
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync($"{baseUrl}?key={_apiKey}", content);

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                throw new Exception($"API call failed: {response.StatusCode} - {errorContent}");
            }

            var responseContent = await response.Content.ReadAsStringAsync();
            var geminiResponse = JsonSerializer.Deserialize<GeminiResponse>(responseContent, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            if (geminiResponse?.Candidates?.FirstOrDefault()?.Content?.Parts?.FirstOrDefault()?.Text != null)
            {
                return geminiResponse.Candidates.First().Content.Parts.First().Text;
            }

            throw new Exception("No valid response received from Gemini API");
        }

        private async Task<string> TryGenerateWithModel(string gameDescription, string model)
        {
            var masterPrompt = GetMasterPrompt(gameDescription);
            var response = await CallGeminiApi(masterPrompt, model);
            return ExtractHtmlCode(response);
        }

        private string GetMasterPrompt(string userGameDescription)
        {
            return $@"
اهم شيء بالنسبه لي هو جمال التصميم  والالوان  ال ui ux   اريد   اقوى ما  لديك

Role and Goal

You are an expert game developer specializing in creating simple, 2D web-based games. Your primary tool is pure JavaScript and the HTML5 Canvas API.

Your task is to take a user's description of a game and write a complete, single, self-contained HTML file that runs this game. The code must be clean, efficient, and immediately executable in a web browser without any external dependencies.

Constraints and Rules (VERY IMPORTANT)

Single File Output: The entire output MUST be a single HTML file. All CSS and JavaScript code must be embedded within this file inside <style> and <script> tags respectively.

No External Libraries: Do NOT use any external JavaScript libraries like p5.js, Phaser, jQuery, etc. You must only use standard browser APIs (HTML5 Canvas, requestAnimationFrame, etc.).

No External Assets: Do NOT include any external images, audio files, or fonts. All graphics must be generated programmatically using Canvas drawing functions (e.g., fillRect, arc, fillStyle). All game elements must be simple geometric shapes (rectangles, circles).

Standard Structure: The HTML file must contain a <canvas> element with the ID 'gameCanvas'. The canvas dimensions should be 800x600 pixels.

Clean and Commented Code: The JavaScript code should be well-structured and include comments explaining the main parts of the game logic (e.g., game loop, player movement, collision detection).

Immediate Execution: The game should start running as soon as the HTML file is loaded.

Input Handling: The game should primarily use keyboard controls (arrow keys, spacebar) for player interaction. Clearly state the controls in the comments of the code.

User's Game Request

Now, based on all the rules above, generate a complete HTML file for the following user request:

User's Request: '{userGameDescription}'

IMPORTANT: Return ONLY the HTML code, nothing else. Start with <!DOCTYPE html> and end with </html>.
";
        }

        private string GetFallbackGame(string gameDescription)
        {
            return @"<!DOCTYPE html>
<html lang='ar'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>لعبة بسيطة - Simple Game</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: Arial, sans-serif;
            color: white;
        }
        canvas {
            border: 3px solid white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .controls {
            position: absolute;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            text-align: center;
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
        }
    </style>
</head>
<body>
    <div class='controls'>
        <h3>🎮 لعبة بسيطة - Simple Game</h3>
        <p>استخدم الأسهم للحركة | Use arrow keys to move</p>
        <p>المسافة للقفز | Spacebar to jump</p>
        <p>النتيجة: <span id='score'>0</span></p>
    </div>
    <canvas id='gameCanvas' width='800' height='600'></canvas>
    
    <script>
        const canvas = document.getElementById('gameCanvas');
        const ctx = canvas.getContext('2d');
        const scoreElement = document.getElementById('score');
        
        let score = 0;
        
        // إعداد اللاعب
        const player = {
            x: 100, y: 500, width: 30, height: 30,
            velocityY: 0, speed: 5, jumping: false,
            color: '#ff6b6b'
        };
        
        // الأعداء والعقبات
        const obstacles = [];
        const particles = [];
        
        // المفاتيح
        const keys = {};
        
        // إضافة مستمعي الأحداث
        document.addEventListener('keydown', (e) => {
            keys[e.code] = true;
            if (e.code === 'Space') e.preventDefault();
        });
        
        document.addEventListener('keyup', (e) => {
            keys[e.code] = false;
        });
        
        // إنشاء عقبة جديدة
        function createObstacle() {
            obstacles.push({
                x: canvas.width,
                y: Math.random() * (canvas.height - 100) + 50,
                width: 30,
                height: 30,
                color: `hsl(${Math.random() * 360}, 70%, 60%)`
            });
        }
        
        // إنشاء جسيمات للتأثيرات
        function createParticle(x, y) {
            for(let i = 0; i < 5; i++) {
                particles.push({
                    x: x, y: y,
                    vx: (Math.random() - 0.5) * 10,
                    vy: (Math.random() - 0.5) * 10,
                    life: 30,
                    color: `hsl(${Math.random() * 360}, 70%, 60%)`
                });
            }
        }
        
        // تحديث اللعبة
        function update() {
            // حركة اللاعب
            if (keys['ArrowLeft'] && player.x > 0) {
                player.x -= player.speed;
            }
            if (keys['ArrowRight'] && player.x < canvas.width - player.width) {
                player.x += player.speed;
            }
            if (keys['Space'] && !player.jumping) {
                player.velocityY = -15;
                player.jumping = true;
            }
            
            // الجاذبية
            player.velocityY += 0.8;
            player.y += player.velocityY;
            
            // فحص الأرض
            if (player.y > canvas.height - player.height - 50) {
                player.y = canvas.height - player.height - 50;
                player.jumping = false;
                player.velocityY = 0;
            }
            
            // تحديث العقبات
            for (let i = obstacles.length - 1; i >= 0; i--) {
                obstacles[i].x -= 3;
                
                // فحص التصادم
                if (player.x < obstacles[i].x + obstacles[i].width &&
                    player.x + player.width > obstacles[i].x &&
                    player.y < obstacles[i].y + obstacles[i].height &&
                    player.y + player.height > obstacles[i].y) {
                    createParticle(obstacles[i].x, obstacles[i].y);
                    obstacles.splice(i, 1);
                    score += 10;
                    scoreElement.textContent = score;
                    continue;
                }
                
                // حذف العقبات التي خرجت من الشاشة
                if (obstacles[i].x + obstacles[i].width < 0) {
                    obstacles.splice(i, 1);
                }
            }
            
            // تحديث الجسيمات
            for (let i = particles.length - 1; i >= 0; i--) {
                particles[i].x += particles[i].vx;
                particles[i].y += particles[i].vy;
                particles[i].life--;
                
                if (particles[i].life <= 0) {
                    particles.splice(i, 1);
                }
            }
            
            // إنشاء عقبات جديدة
            if (Math.random() < 0.02) {
                createObstacle();
            }
        }
        
        // رسم اللعبة
        function draw() {
            // خلفية متدرجة
            const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
            gradient.addColorStop(0, '#4facfe');
            gradient.addColorStop(1, '#00f2fe');
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // رسم الأرض
            ctx.fillStyle = '#2ecc71';
            ctx.fillRect(0, canvas.height - 50, canvas.width, 50);
            
            // رسم اللاعب
            ctx.fillStyle = player.color;
            ctx.shadowColor = player.color;
            ctx.shadowBlur = 10;
            ctx.fillRect(player.x, player.y, player.width, player.height);
            ctx.shadowBlur = 0;
            
            // رسم العقبات
            obstacles.forEach(obstacle => {
                ctx.fillStyle = obstacle.color;
                ctx.shadowColor = obstacle.color;
                ctx.shadowBlur = 5;
                ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
                ctx.shadowBlur = 0;
            });
            
            // رسم الجسيمات
            particles.forEach(particle => {
                ctx.fillStyle = particle.color;
                ctx.globalAlpha = particle.life / 30;
                ctx.fillRect(particle.x, particle.y, 3, 3);
                ctx.globalAlpha = 1;
            });
        }
        
        // حلقة اللعبة الرئيسية
        function gameLoop() {
            update();
            draw();
            requestAnimationFrame(gameLoop);
        }
        
        // بدء اللعبة
        gameLoop();
    </script>
</body>
</html>";
        }

        private string ExtractHtmlCode(string responseText)
        {
            var htmlStart = responseText.IndexOf("<!DOCTYPE html>");
            if (htmlStart == -1)
            {
                htmlStart = responseText.IndexOf("<html>");
            }
            
            var htmlEnd = responseText.LastIndexOf("</html>");
            
            if (htmlStart != -1 && htmlEnd != -1)
            {
                return responseText.Substring(htmlStart, htmlEnd - htmlStart + 7);
            }
            
            // If no proper HTML structure found, return the entire response
            return responseText;
        }
    }

    // Response models for Gemini API
    public class GeminiResponse
    {
        public Candidate[]? Candidates { get; set; }
    }

    public class Candidate
    {
        public Content? Content { get; set; }
    }

    public class Content
    {
        public Part[]? Parts { get; set; }
    }

    public class Part
    {
        public string? Text { get; set; }
    }
}