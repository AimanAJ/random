using System.Diagnostics;
using gamegenerater.Models;
using gamegenerater.Services;
using Microsoft.AspNetCore.Mvc;

namespace gamegenerater.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly GeminiApiService _geminiApiService;

        public HomeController(ILogger<HomeController> logger, GeminiApiService geminiApiService)
        {
            _logger = logger;
            _geminiApiService = geminiApiService;
        }

        public IActionResult Index()
        {
            var model = new GameRequest();
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Generate(GameRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Description))
            {
                request.ErrorMessage = "???? ????? ??? ????? ?????";
                return View("Index", request);
            }

            try
            {
                request.IsGenerating = true;
                _logger.LogInformation($"Generating game for description: {request.Description}");
                
                var generatedCode = await _geminiApiService.GenerateGameAsync(request.Description);
                request.GeneratedCode = generatedCode;
                request.IsGenerating = false;
                
                _logger.LogInformation("Game generated successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating game");
                request.ErrorMessage = $"??? ?? ????? ??????: {ex.Message}";
                request.IsGenerating = false;
            }

            return View("Index", request);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
