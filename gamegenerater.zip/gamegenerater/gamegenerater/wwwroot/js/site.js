﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

// AI Game Generator - Custom JavaScript utilities

// Function to show loading state
function showLoading() {
    const button = document.querySelector('button[type="submit"]');
    if (button) {
        button.disabled = true;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Generating Game...';
    }
}

// Function to hide loading state
function hideLoading() {
    const button = document.querySelector('button[type="submit"]');
    if (button) {
        button.disabled = false;
        button.innerHTML = '🚀 Generate Game';
    }
}

// Function to validate game description
function validateDescription() {
    const textarea = document.getElementById('description');
    const description = textarea.value.trim();
    
    if (description.length < 10) {
        showAlert('Please provide a more detailed game description (at least 10 characters).', 'warning');
        return false;
    }
    
    if (description.length > 2000) {
        showAlert('Game description is too long. Please keep it under 2000 characters.', 'warning');
        return false;
    }
    
    return true;
}

// Function to show alerts
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    const container = document.querySelector('.container-fluid');
    container.insertBefore(alertDiv, container.firstChild);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

// Function to format code in the modal
function formatCode() {
    const codeElement = document.getElementById('generatedCode');
    if (codeElement) {
        // Simple code formatting (basic indentation)
        let code = codeElement.textContent;
        code = code.replace(/></g, '>\n<');
        code = code.replace(/\n\s*\n/g, '\n');
        codeElement.textContent = code;
    }
}

// Function to refresh game preview
function refreshPreview() {
    const iframe = document.getElementById('gameFrame');
    if (iframe) {
        const src = iframe.getAttribute('srcdoc');
        iframe.setAttribute('srcdoc', '');
        setTimeout(() => {
            iframe.setAttribute('srcdoc', src);
        }, 100);
    }
}

// Enhanced copy to clipboard with error handling
async function copyToClipboardEnhanced(text) {
    try {
        if (navigator.clipboard && window.isSecureContext) {
            await navigator.clipboard.writeText(text);
            return true;
        } else {
            // Fallback method
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            const successful = document.execCommand('copy');
            document.body.removeChild(textArea);
            return successful;
        }
    } catch (err) {
        console.error('Failed to copy text: ', err);
        return false;
    }
}

// Character counter for textarea
function updateCharacterCount() {
    const textarea = document.getElementById('description');
    const counter = document.getElementById('charCounter');
    
    if (textarea && counter) {
        const currentLength = textarea.value.length;
        const maxLength = 2000;
        counter.textContent = `${currentLength}/${maxLength} characters`;
        
        if (currentLength > maxLength * 0.9) {
            counter.classList.add('text-warning');
        } else {
            counter.classList.remove('text-warning');
        }
        
        if (currentLength > maxLength) {
            counter.classList.add('text-danger');
            counter.classList.remove('text-warning');
        } else {
            counter.classList.remove('text-danger');
        }
    }
}

// Initialize page functionality
document.addEventListener('DOMContentLoaded', function() {
    // Add character counter if textarea exists
    const textarea = document.getElementById('description');
    if (textarea) {
        // Create character counter
        const counterDiv = document.createElement('div');
        counterDiv.innerHTML = '<small id="charCounter" class="text-muted">0/2000 characters</small>';
        textarea.parentNode.appendChild(counterDiv);
        
        // Add event listener for character counting
        textarea.addEventListener('input', updateCharacterCount);
        updateCharacterCount(); // Initial count
        
        // Add form validation
        const form = textarea.closest('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                if (!validateDescription()) {
                    e.preventDefault();
                }
            });
        }
    }
    
    // Format code in modal when it opens
    const codeModal = document.getElementById('codeModal');
    if (codeModal) {
        codeModal.addEventListener('shown.bs.modal', formatCode);
    }
    
    // Add fullscreen functionality to game preview
    const gameFrame = document.getElementById('gameFrame');
    if (gameFrame) {
        // Add fullscreen button
        const cardHeader = gameFrame.closest('.card').querySelector('.card-header');
        if (cardHeader && !cardHeader.querySelector('.fullscreen-btn')) {
            const fullscreenBtn = document.createElement('button');
            fullscreenBtn.type = 'button';
            fullscreenBtn.className = 'btn btn-sm btn-outline-secondary fullscreen-btn ms-2';
            fullscreenBtn.innerHTML = '⛶ Fullscreen';
            fullscreenBtn.onclick = toggleFullscreen;
            cardHeader.appendChild(fullscreenBtn);
        }
    }
});

// Fullscreen functionality
function toggleFullscreen() {
    const gameFrame = document.getElementById('gameFrame');
    if (!gameFrame) return;
    
    if (!document.fullscreenElement) {
        gameFrame.requestFullscreen().then(() => {
            gameFrame.style.width = '100vw';
            gameFrame.style.height = '100vh';
        }).catch(err => {
            console.error('Error attempting to enable fullscreen:', err);
        });
    } else {
        document.exitFullscreen();
    }
}

// Listen for fullscreen changes
document.addEventListener('fullscreenchange', function() {
    const gameFrame = document.getElementById('gameFrame');
    if (gameFrame && !document.fullscreenElement) {
        // Restore normal size when exiting fullscreen
        gameFrame.style.width = '100%';
        gameFrame.style.height = '600px';
    }
});

// Sample game descriptions for quick testing
const sampleDescriptions = [
    "A space shooter game where the player controls a spaceship and shoots at incoming asteroids. The player can move left and right using arrow keys and shoot with spacebar.",
    "A simple Snake game where the player controls a snake that moves around the screen and grows when eating food. Use arrow keys to control direction.",
    "A Pong game with two paddles bouncing a ball. One paddle is controlled by the player using up and down arrow keys, the other is AI-controlled.",
    "A brick breaker game where a paddle bounces a ball to destroy colorful bricks at the top of the screen. Player controls the paddle with left and right arrow keys.",
    "A simple platformer where a character can jump between platforms and collect coins. Use arrow keys to move and spacebar to jump."
];

// Function to insert sample description
function insertSampleDescription() {
    const textarea = document.getElementById('description');
    if (textarea && sampleDescriptions.length > 0) {
        const randomDescription = sampleDescriptions[Math.floor(Math.random() * sampleDescriptions.length)];
        textarea.value = randomDescription;
        updateCharacterCount();
    }
}
