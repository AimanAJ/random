namespace gamegenerater.Models
{
    public class GameRequest
    {
        public string Description { get; set; } = string.Empty;
        public string GeneratedCode { get; set; } = string.Empty;
        public bool IsGenerating { get; set; } = false;
        public string ErrorMessage { get; set; } = string.Empty;
    }
}