# AI Game Generator

An ASP.NET Core MVC application that uses Google's Gemini AI to generate complete HTML5 games based on text descriptions.

## Features

- ?? **AI-Powered Game Generation**: Describe your game idea and get a complete HTML5 game
- ?? **Simple Interface**: Easy-to-use web interface for game description input
- ?? **Live Preview**: Instant preview of generated games in the browser
- ?? **Download Games**: Download generated games as standalone HTML files
- ?? **Code Viewing**: View and copy the generated game code

## Setup Instructions

### 1. Get a Gemini API Key

1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Sign in with your Google account
3. Create a new API key
4. Copy the API key

### 2. Configure the API Key

1. Open `appsettings.json`
2. Replace `YOUR_GEMINI_API_KEY_HERE` with your actual API key:

```json
{
  "GeminiApi": {
    "ApiKey": "your_actual_api_key_here"
  }
}
```

### 3. Run the Application

1. Open the project in Visual Studio
2. Press F5 or click "Start" to run the application
3. Navigate to the home page
4. Enter a game description and click "Generate Game"

## Example Game Descriptions

Here are some example game descriptions you can try:

### Simple Games
- "A Pong game where two paddles bounce a ball back and forth"
- "A Snake game where the player controls a snake that grows when eating food"
- "A simple platformer where a character jumps between platforms"

### Action Games
- "A space shooter where the player shoots at incoming asteroids"
- "A top-down tank game where the player destroys enemy tanks"
- "A brick breaker game where a paddle bounces a ball to destroy blocks"

### Puzzle Games
- "A memory card matching game with colored squares"
- "A simple Tetris-like game with falling blocks"
- "A maze game where the player navigates to reach the exit"

## Project Structure

```
gamegenerater/
??? Controllers/
?   ??? HomeController.cs          # Main controller with game generation logic
??? Models/
?   ??? GameRequest.cs            # Model for game generation requests
?   ??? ErrorViewModel.cs         # Error handling model
??? Services/
?   ??? GeminiApiService.cs       # Service for Gemini AI API integration
??? Views/
?   ??? Home/
?   ?   ??? Index.cshtml          # Main UI for game generation
?   ??? Shared/
?       ??? _Layout.cshtml        # Layout template
??? wwwroot/
?   ??? css/
?   ?   ??? site.css             # Custom styling
?   ??? js/
?       ??? site.js              # Custom JavaScript
??? appsettings.json             # Configuration including API key
??? Program.cs                   # Application startup
```

## How It Works

1. **User Input**: User enters a game description in the textarea
2. **AI Processing**: The description is sent to Gemini AI with a detailed prompt
3. **Game Generation**: Gemini AI generates a complete HTML5 game with JavaScript
4. **Preview**: The generated game is displayed in an iframe for immediate testing
5. **Download**: Users can download the game as a standalone HTML file

## Technical Details

- **Framework**: ASP.NET Core 8.0 MVC
- **AI Service**: Google Gemini Pro API
- **Frontend**: Bootstrap 5, vanilla JavaScript
- **Game Technology**: HTML5 Canvas API, pure JavaScript (no external libraries)

## Troubleshooting

### API Key Issues
- Ensure your API key is correctly set in `appsettings.json`
- Check that your Google Cloud project has the Gemini API enabled
- Verify you have sufficient API quota

### Build Issues
- Ensure you have .NET 8.0 SDK installed
- Check that all NuGet packages are restored

### Game Generation Issues
- Try simpler game descriptions if complex ones fail
- Check the browser console for JavaScript errors in generated games
- Ensure your internet connection is stable for API calls

## Contributing

Feel free to submit issues and enhancement requests!

## License

This project is for educational purposes. Please ensure you comply with Google's API usage terms.